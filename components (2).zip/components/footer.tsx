import Link from "next/link"
import Image from "next/image"
import { Phone, Mail, MapPin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12 relative overflow-hidden">
      {/* Gradient background effects */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,rgba(147,51,234,0.5)_0%,rgba(0,0,0,0)_50%)]"></div>
        <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_80%,rgba(79,70,229,0.5)_0%,rgba(0,0,0,0)_50%)]"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <Link href="/" className="block mb-4">
              <Image src="/logo.png" alt="VTelco" width={150} height={50} className="h-8 w-auto" />
            </Link>
            <p className="text-gray-400 text-sm">Simplificando sua rede</p>
          </div>

          <div>
            <h4 className="font-medium mb-4 text-white text-sm uppercase tracking-wider">Links rápidos</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <Link href="/" className="hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/#solucoes" className="hover:text-white transition-colors">
                  Soluções
                </Link>
              </li>
              <li>
                <Link href="/#sobre" className="hover:text-white transition-colors">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link href="/#contato" className="hover:text-white transition-colors">
                  Contato
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-4 text-white text-sm uppercase tracking-wider">Soluções</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>
                <Link href="/switches" className="hover:text-white transition-colors">
                  Switches
                </Link>
              </li>
              <li>
                <Link href="/virtualizacao" className="hover:text-white transition-colors">
                  Virtualização
                </Link>
              </li>
              <li>
                <Link href="/visibilidade-e-seguranca" className="hover:text-white transition-colors">
                  Visibilidade e Segurança
                </Link>
              </li>
              <li>
                <Link href="/treinamentos" className="hover:text-white transition-colors">
                  Treinamentos
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-4 text-white text-sm uppercase tracking-wider">Contato</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-gray-500" />
                <span>+55 (41) 99988-9681</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-gray-500" />
                <span>contato@vtelco.com.br</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-gray-500 mt-1" />
                <span>Rua Imaculada Conceição, 1430 – Prado Velho, Curitiba – PR</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} VTelco. Todos os direitos reservados.
          </p>

          <div className="flex space-x-4">
            <Link href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
              Política de Privacidade
            </Link>
            <Link href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
              Termos de Uso
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

