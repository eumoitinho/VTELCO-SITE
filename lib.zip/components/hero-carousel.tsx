"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, ArrowRight } from "lucide-react"

interface HeroSlide {
  title: string
  description: string
  image: string
}

export default function HeroCarousel() {
  const slides: HeroSlide[] = [
    {
      title: "Nova era para as redes ópticas",
      description:
        "Com a implementação do 400G Open ZR+ (MSA), sua rede ganhará escalabilidade suportando até 400Gbps de throughput sem a necessidade de equipamentos DWDM, interligado através de transceivers QSFP-DD conectados diretamente ao seu roteador.",
      image: "/images/hero-bg-1.webp",
    },
    {
      title: "Proteja sua rede contra ameaças digitais",
      description:
        "As soluções de segurança da Netscout protegem sua rede contra ataques DDOS (Distributed Denial Of Service) e garantem a integridade, confiabilidade e autenticidade dos seus dados, com visibilidade única.",
      image: "/images/hero-bg-2.webp",
    },
    {
      title: "Solução de roteamento virtual de alto desempenho",
      description:
        "Com as soluções virtualizadas de BNG e CGNAT da netElastic, seu provedor ganhará escalabilidade, agilidade e elasticidade, desenvolvendo sua rede de forma simples e trazendo a visibilidade em tela única para administrar todos os seus POPs.",
      image: "/images/hero-bg-3.webp",
    },
  ]

  const [currentSlide, setCurrentSlide] = useState(0)

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1))
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1))
  }

  const goToSlide = (index: number) => {
    setCurrentSlide(index)
  }

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide()
    }, 5000)

    return () => clearInterval(interval)
  }, [currentSlide])

  return (
    <section className="relative dark-purple-bg text-white overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#1a0b2e] via-[#2a0e46] to-[#3a1e56]">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,rgba(147,51,234,0.5)_0%,rgba(0,0,0,0)_50%)]"></div>
          <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_80%,rgba(79,70,229,0.5)_0%,rgba(0,0,0,0)_50%)]"></div>
        </div>
      </div>

      <div className="absolute left-4 top-1/2 -translate-y-1/2 z-10">
        <Button variant="ghost" size="icon" className="rounded-full text-white hover:bg-white/10" onClick={prevSlide}>
          <ChevronLeft className="h-6 w-6" />
          <span className="sr-only">Previous slide</span>
        </Button>
      </div>

      <div className="absolute right-4 top-1/2 -translate-y-1/2 z-10">
        <Button variant="ghost" size="icon" className="rounded-full text-white hover:bg-white/10" onClick={nextSlide}>
          <ChevronRight className="h-6 w-6" />
          <span className="sr-only">Next slide</span>
        </Button>
      </div>

      <div className="relative min-h-[600px] w-full overflow-hidden">
        {slides.map((slide, index) => (
          <div key={index} className={`hero-slide ${index === currentSlide ? "active" : ""}`}>
            <div className="container min-h-[600px] flex flex-col justify-center px-4 md:px-6 py-20 md:py-32">
              <div className={`max-w-3xl ${index === currentSlide ? "slide-in-right" : ""}`}>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">{slide.title}</h1>
                <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-2xl">{slide.description}</p>
                <Button className="bg-[#9333ea] hover:bg-[#7e22ce] text-white text-lg px-8 py-6 h-auto rounded-md group">
                  QUERO SABER MAIS!
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="carousel-dots">
        {slides.map((_, index) => (
          <div
            key={index}
            className={`carousel-dot ${index === currentSlide ? "active" : ""}`}
            onClick={() => goToSlide(index)}
          />
        ))}
      </div>

      <div className="absolute bottom-0 left-0 w-full h-20 bg-gradient-to-t from-[#f8f9fa] to-transparent"></div>
    </section>
  )
}

