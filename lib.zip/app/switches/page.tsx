"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import {
  ArrowRight,
  Menu,
  X,
  CheckCircle2,
  ShieldCheck,
  BarChart3,
  Settings,
  Lightbulb,
  CreditCard,
  Network,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Zap,
  Lock,
  LayoutGrid,
  LineChart,
  Phone,
  Mail,
  MapPin,
  Send,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { motion, useScroll, useTransform, useInView, AnimatePresence } from "framer-motion"

export default function SwitchesPage() {
  const { scrollY } = useScroll()

  // Refs for sections
  const heroRef = useRef<HTMLDivElement>(null)
  const infoRef = useRef<HTMLDivElement>(null)
  const featuresRef = useRef<HTMLDivElement>(null)
  const productsRef = useRef<HTMLDivElement>(null)
  const whyUsRef = useRef<HTMLDivElement>(null)
  const aboutRef = useRef<HTMLDivElement>(null)
  const contactRef = useRef<HTMLDivElement>(null)

  // InView states for animations
  const heroInView = useInView(heroRef, { once: true, amount: 0.3 })
  const infoInView = useInView(infoRef, { once: true, amount: 0.3 })
  const featuresInView = useInView(featuresRef, { once: true, amount: 0.3 })
  const productsInView = useInView(productsRef, { once: true, amount: 0.3 })
  const whyUsInView = useInView(whyUsRef, { once: true, amount: 0.3 })
  const aboutInView = useInView(aboutRef, { once: true, amount: 0.3 })
  const contactInView = useInView(contactRef, { once: true, amount: 0.3 })

  // UI state
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [mobileSubmenuOpen, setMobileSubmenuOpen] = useState(false)
  const [activeProduct, setActiveProduct] = useState(0)

  // Products data
  const products = [
    {
      name: "UFI Space",
      tagline: "Especialista em switches de alta performance",
      description: [
        "A UfiSpace, fundada em 2015 e com sede em Taiwan, é especializada em switches de alta performance para provedores de serviços e data centers. Para provedores de serviços, a empresa oferece equipamentos que variam de 4 portas de 1 Gbps a 36 portas de 400 Gbps, ideais para roteadores de Ponto de Entrada (PE) e Borda.",
        "Já para data centers, a UfiSpace disponibiliza switches de alta capacidade, com opções que variam de 24 portas de 10 Gbps a 64 portas de 800 Gbps, garantindo a transferência eficiente de grandes volumes de dados.",
      ],
      features: [
        "Suporte a BGP e MPLS",
        "Serviços L2VPN e L3VPN",
        "Alta capacidade de tráfego",
        "Flexibilidade de configuração",
      ],
      image: "/ufispace.png",
      icon: <Network className="h-10 w-10" />,
      color: "from-purple-600 to-indigo-600",
    },
    {
      name: "Edgecore Networks",
      tagline: "Líder em soluções de rede desagregadas",
      description: [
        "A Edgecore Networks, fundada em 2004, é líder no fornecimento de soluções de rede desagregadas e de código aberto. A Edgecore se destaca por permitir que operadoras de telecomunicações, provedores de serviços e data centers construam redes personalizadas, escaláveis e eficientes.",
        "Para data centers, a Edgecore oferece switches de alta capacidade com portas de 1 Gbps até 400 Gbps, enquanto para empresas, disponibiliza uma linha completa de switches L2 e L3 e Wi-Fi.",
      ],
      features: [
        "Arquitetura modular e redundante",
        "Switches PoE de 8 a 48 portas",
        "Alta performance",
        "Código aberto",
      ],
      image: "/edcore.png",
      icon: <Settings className="h-10 w-10" />,
      color: "from-blue-600 to-cyan-600",
    },
    {
      name: "Asterfusion",
      tagline: "Soluções de rede desagregada para alta performance",
      description: [
        "A Asterfusion é uma empresa especializada em soluções de rede desagregada e de código aberto, projetadas para atender às necessidades de data centers, provedores de nuvem e redes de telecomunicações.",
        "Para data centers, a empresa disponibiliza switches com ultra baixa latência (400 ns) e capacidades de até 36 portas de 400 Gbps, ideais para ambientes que exigem altíssima performance e transferência rápida de dados.",
      ],
      features: [
        "Ultra baixa latência (400 ns)",
        "Suporte a SDN e NFV",
        "Até 36 portas de 400 Gbps",
        "Infraestrutura escalável",
      ],
      image: "/asterfusion.webp",
      icon: <BarChart3 className="h-10 w-10" />,
      color: "from-indigo-600 to-purple-600",
    },
    {
      name: "ACORID",
      tagline: "Soluções de rede para todos os ambientes",
      description: [
        "A ACORID é uma empresa chinesa especializada em soluções de rede para ambientes empresariais, industriais e residenciais. Seu portfólio inclui switches PoE, Ethernet e industriais, oferecendo um equilíbrio entre custo-benefício, eficiência e confiabilidade.",
        "Os switches PoE permitem a transmissão simultânea de dados e energia por meio de cabos Ethernet, sendo ideais para alimentar dispositivos como câmeras IP, pontos de acesso Wi-Fi e telefones VoIP, sem necessidade de fontes de energia externas.",
      ],
      features: [
        "Switches PoE e Ethernet",
        "Proteção contra sobrecarga",
        "Excelente custo-benefício",
        "Alta durabilidade",
      ],
      image: "/placeholder.svg?height=400&width=400",
      icon: <ShieldCheck className="h-10 w-10" />,
      color: "from-purple-600 to-pink-600",
    },
  ]

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    // Smooth scroll for navigation links
    const handleLinkClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      if (target.tagName === "A" && target.getAttribute("href")?.startsWith("#")) {
        e.preventDefault()
        const id = target.getAttribute("href")?.substring(1)
        const element = document.getElementById(id || "")
        if (element) {
          window.scrollTo({
            top: element.offsetTop - 100,
            behavior: "smooth",
          })
        }
      }
    }

    // Auto-rotate products
    const productInterval = setInterval(() => {
      setActiveProduct((prev) => (prev + 1) % products.length)
    }, 8000)

    window.addEventListener("scroll", handleScroll)
    document.addEventListener("click", handleLinkClick)

    return () => {
      window.removeEventListener("scroll", handleScroll)
      document.removeEventListener("click", handleLinkClick)
      clearInterval(productInterval)
    }
  }, [products.length])

  return (
    <div className="flex flex-col min-h-screen bg-[#f8f9fa] overflow-x-hidden">
      {/* Header */}
      <header
        className={`fixed top-0 z-50 w-full ${
          scrolled ? "bg-[#1a0b2e]/90 backdrop-blur-sm shadow-lg" : "bg-[#1a0b2e]"
        } text-white transition-all duration-500`}
      >
        <div className="container flex h-20 items-center justify-between px-4 md:px-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-2"
          >
            <Link href="/" className="flex items-center gap-2 relative group">
              <div className="absolute -inset-2 bg-gradient-to-r from-[#9333ea]/20 to-[#4f46e5]/20 rounded-full blur opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <Image
                src="/logo.png"
                alt="VTelco"
                width={150}
                height={50}
                className="h-10 w-auto relative"
              />
            </Link>
          </motion.div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-8">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Link
                href="/"
                className="text-sm font-medium text-white/80 hover:text-white transition-colors relative group"
              >
                Home
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative group"
            >
              <Link
                href="#"
                className="text-sm font-medium text-white/80 hover:text-white transition-colors flex items-center gap-1 relative"
              >
                Soluções
                <ChevronDown className="h-4 w-4" />
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <div className="absolute left-0 mt-2 w-64 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 ease-in-out z-50 transform origin-top scale-95 group-hover:scale-100">
                <div className="py-2 px-1">
                  <div className="group/item py-1 px-1">
                    <Link
                      href="/switches"
                      className="block px-4 py-3 text-sm text-gray-700 hover:bg-purple-50 hover:text-purple-700 rounded-md transition-colors"
                    >
                      Switches
                    </Link>
                  </div>
                  <div className="group/item py-1 px-1">
                    <Link
                      href="/virtualizacao"
                      className="block px-4 py-3 text-sm text-gray-700 hover:bg-purple-50 hover:text-purple-700 rounded-md transition-colors"
                    >
                      Virtualização de Redes
                    </Link>
                  </div>
                  <div className="group/item py-1 px-1">
                    <Link
                      href="/visibilidade-e-seguranca"
                      className="block px-4 py-3 text-sm text-gray-700 hover:bg-purple-50 hover:text-purple-700 rounded-md transition-colors"
                    >
                      Visibilidade e Segurança
                    </Link>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Link
                href="#sobre"
                className="text-sm font-medium text-white/80 hover:text-white transition-colors relative group"
              >
                Sobre Nós
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Link
                href="#formulario"
                className="text-sm font-medium text-white/80 hover:text-white transition-colors relative group"
              >
                Contato
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
              </Link>
            </motion.div>
          </nav>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden text-white relative group"
                onClick={() => setMenuOpen(!menuOpen)}
              >
                <div className="absolute inset-0 rounded-full bg-white/10 scale-0 group-hover:scale-100 transition-transform duration-300"></div>
                {menuOpen ? <X className="h-6 w-6 relative" /> : <Menu className="h-6 w-6 relative" />}
              </Button>
            </motion.div>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              className="md:hidden bg-[#1a0b2e] absolute top-20 left-0 w-full py-4"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="container px-4 flex flex-col space-y-4">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.1 }}
                >
                  <Link
                    href="/"
                    className="text-white py-2 px-4 rounded hover:bg-white/10 block transition-colors"
                    onClick={() => setMenuOpen(false)}
                  >
                    Home
                  </Link>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.2 }}
                >
                  <div
                    className="text-white py-2 px-4 rounded hover:bg-white/10 block transition-colors cursor-pointer flex items-center justify-between"
                    onClick={() => setMobileSubmenuOpen(!mobileSubmenuOpen)}
                  >
                    <span>Soluções</span>
                    {mobileSubmenuOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </div>

                  <AnimatePresence>
                    {mobileSubmenuOpen && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.2 }}
                        className="pl-4 mt-2 space-y-2"
                      >
                        <Link
                          href="/switches"
                          className="text-white/80 py-2 px-4 rounded hover:bg-white/10 block transition-colors"
                          onClick={() => setMenuOpen(false)}
                        >
                          Switches
                        </Link>
                        <Link
                          href="/virtualizacao"
                          className="text-white/80 py-2 px-4 rounded hover:bg-white/10 block transition-colors"
                          onClick={() => setMenuOpen(false)}
                        >
                          Virtualização de Redes
                        </Link>
                        <Link
                          href="/visibilidade-e-seguranca"
                          className="text-white/80 py-2 px-4 rounded hover:bg-white/10 block transition-colors"
                          onClick={() => setMenuOpen(false)}
                        >
                          Visibilidade e Segurança
                        </Link>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.3 }}
                >
                  <Link
                    href="#sobre"
                    className="text-white py-2 px-4 rounded hover:bg-white/10 block transition-colors"
                    onClick={() => setMenuOpen(false)}
                  >
                    Sobre Nós
                  </Link>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.4 }}
                >
                  <Link
                    href="#formulario"
                    className="text-white py-2 px-4 rounded hover:bg-white/10 block transition-colors"
                    onClick={() => setMenuOpen(false)}
                  >
                    Contato
                  </Link>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main className="flex-1 pt-20">
        {/* Hero Section - Bloco 1 */}
        <section ref={heroRef} className="relative bg-[#1a0b2e] text-white overflow-hidden">
          <div className="absolute inset-0 overflow-hidden">
            <motion.div
              className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(147,51,234,0.5)_0%,rgba(0,0,0,0)_50%)]"
              style={{
                y: useTransform(scrollY, [0, 300], [0, 100]),
                scale: useTransform(scrollY, [0, 300], [1, 1.1]),
              }}
            ></motion.div>
            <motion.div
              className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_80%,rgba(79,70,229,0.5)_0%,rgba(0,0,0,0)_50%)]"
              style={{
                y: useTransform(scrollY, [0, 300], [0, -50]),
                scale: useTransform(scrollY, [0, 300], [1, 1.05]),
              }}
            ></motion.div>
          </div>

          <div className="container relative min-h-[700px] md:min-h-[800px] flex flex-col justify-center px-4 md:px-6 py-20 md:py-32">
            <div className="absolute top-0 right-0 w-full h-full pointer-events-none">
              <div className="absolute top-[20%] right-[10%] w-64 h-64 bg-purple-500/20 rounded-full filter blur-3xl"></div>
              <div className="absolute bottom-[30%] left-[5%] w-48 h-48 bg-blue-500/20 rounded-full filter blur-3xl"></div>

              {/* Network lines animation */}
              <svg
                className="absolute inset-0 w-full h-full opacity-20"
                viewBox="0 0 100 100"
                preserveAspectRatio="none"
              >
                <motion.path
                  d="M0,50 Q25,30 50,50 T100,50"
                  stroke="url(#gradient1)"
                  strokeWidth="0.2"
                  fill="none"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, repeatType: "loop", ease: "linear" }}
                />
                <motion.path
                  d="M0,30 Q35,60 70,30 T100,30"
                  stroke="url(#gradient1)"
                  strokeWidth="0.2"
                  fill="none"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{
                    duration: 3,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "loop",
                    ease: "linear",
                    delay: 0.5,
                  }}
                />
                <motion.path
                  d="M0,70 Q50,40 75,70 T100,70"
                  stroke="url(#gradient1)"
                  strokeWidth="0.2"
                  fill="none"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{
                    duration: 2.5,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "loop",
                    ease: "linear",
                    delay: 1,
                  }}
                />
                <defs>
                  <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#9333ea" />
                    <stop offset="100%" stopColor="#4f46e5" />
                  </linearGradient>
                </defs>
              </svg>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={
                heroInView
                  ? {
                      opacity: 1,
                      y: 0,
                      transition: {
                        duration: 0.8,
                        delay: 0.2,
                      },
                    }
                  : {}
              }
              className="max-w-3xl relative z-10"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={heroInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="inline-block mb-4 px-4 py-1.5 bg-white/10 backdrop-blur-sm rounded-full text-sm font-medium"
              >
                Soluções de Conectividade
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={heroInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/80"
              >
                CONECTIVIDADE SEM LIMITES
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={heroInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="text-xl md:text-2xl mb-8 text-white/90 max-w-2xl"
              >
                Switches de alto desempenho para elevar o nível da sua rede
              </motion.p>

              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={heroInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.7 }}
                className="text-lg mb-10 text-white/80 max-w-2xl"
              >
                A VTelco dispõe de uma ampla variedade de switches de alta performance, garantindo escalabilidade,
                segurança, gerenciamento simplificado e baixa latência para um fluxo de dados ágil e confiável.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={heroInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.9 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button className="bg-gradient-to-r from-[#9333ea] to-[#4f46e5] hover:from-[#8323d5] hover:to-[#4038c7] text-white text-lg px-8 py-6 h-auto rounded-full group relative overflow-hidden shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all duration-300">
                  <span className="relative z-10">QUERO SABER MAIS!</span>
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1 relative z-10" />
                </Button>
              </motion.div>
            </motion.div>
          </div>

          <div className="absolute bottom-0 left-0 w-full h-20 bg-gradient-to-t from-[#f8f9fa] to-transparent"></div>
        </section>

        {/* Info Section - Bloco 2 */}
        <section ref={infoRef} className="py-20 bg-[#f8f9fa]">
          <div className="container px-4 md:px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={infoInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.8 }}
              >
                <div className="inline-block mb-4 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                  Tecnologia de Ponta
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6 text-[#1a0b2e]">
                  Conectividade, escalabilidade e segurança para sua empresa
                </h2>
                <p className="text-gray-700 mb-6 text-lg">
                  Switches são dispositivos de rede que atuam como pontos de conexão entre vários dispositivos em uma
                  rede local. Eles são responsáveis por encaminhar o tráfego de dados entre os dispositivos conectados,
                  garantindo que as informações cheguem ao seu destino de forma rápida e eficiente.
                </p>
                <p className="text-gray-700 mb-8 text-lg">
                  Investir em switches de qualidade significa reduzir falhas na comunicação, aumentar a produtividade e
                  fortalecer infraestruturas de TI, tornando sua empresa mais preparada para crescer e se adaptar às
                  demandas do mercado digital.
                </p>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button className="bg-gradient-to-r from-[#9333ea] to-[#4f46e5] hover:from-[#8323d5] hover:to-[#4038c7] text-white px-8 py-6 h-auto rounded-full group relative overflow-hidden shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all duration-300">
                    <span className="relative z-10">QUERO SABER MAIS!</span>
                    <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1 relative z-10" />
                  </Button>
                </motion.div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={infoInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative"
              >
                <div className="relative rounded-2xl overflow-hidden shadow-xl">
                  <div className="absolute inset-0 bg-gradient-to-br from-[#1a0b2e] via-[#2a0e46] to-[#3a1e56] opacity-80"></div>
                  <div className="aspect-video relative z-10 flex items-center justify-center">
                  <div className="w-3/4 h-3/4 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20 p-6 flex items-center justify-center">
                    <div className="w-full h-full bg-[#1a0b2e]/50 rounded flex items-center justify-center">
                    <Image
                      src={"/hero.webp"}
                      alt="Switches"
                      layout="fill"
                      objectFit="cover"
                      className="rounded"
                    />
                    </div>
                  </div>
                  </div>
                </div>

                {/* Decorative elements */}
                <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-[#9333ea]/20 rounded-full blur-xl"></div>
                <div className="absolute -top-6 -left-6 w-32 h-32 bg-[#4f46e5]/20 rounded-full blur-xl"></div>

                {/* Floating network icons */}
                <motion.div
                  className="absolute -top-4 -right-4 bg-white/10 backdrop-blur-sm p-3 rounded-xl shadow-lg"
                  animate={{
                    y: [0, -10, 0],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                  }}
                >
                  <Network className="h-8 w-8 text-purple-500" />
                </motion.div>

                <motion.div
                  className="absolute -bottom-4 -left-4 bg-white/10 backdrop-blur-sm p-3 rounded-xl shadow-lg"
                  animate={{
                    y: [0, 10, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                    delay: 1,
                  }}
                >
                  <Zap className="h-8 w-8 text-blue-500" />
                </motion.div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Features Section - Bloco 3 */}
        <section ref={featuresRef} className="py-20 bg-white relative overflow-hidden">
          <motion.div
            className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_0%_0%,rgba(147,51,234,0.1)_0%,rgba(0,0,0,0)_50%)]"
            style={{
              y: useTransform(
                scrollY,
                [featuresRef.current?.offsetTop || 0, (featuresRef.current?.offsetTop || 0) + 300],
                [0, 100],
              ),
            }}
          ></motion.div>
          <motion.div
            className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(circle_at_100%_100%,rgba(79,70,229,0.1)_0%,rgba(0,0,0,0)_50%)]"
            style={{
              y: useTransform(
                scrollY,
                [featuresRef.current?.offsetTop || 0, (featuresRef.current?.offsetTop || 0) + 300],
                [0, -100],
              ),
            }}
          ></motion.div>

          <div className="container px-4 md:px-6 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={featuresInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                Benefícios
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-[#1a0b2e]">
                Principais benefícios dos nossos switches
              </h2>
              <div className="w-20 h-1 bg-gradient-to-r from-[#9333ea] to-[#4f46e5] mx-auto"></div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  title: "Desempenho",
                  description:
                    "Garantimos uma comunicação rápida e eficiente entre dispositivos, reduzindo congestionamentos e otimizando a transmissão de dados.",
                  icon: <Zap className="w-12 h-12" />,
                  color: "from-purple-600 to-indigo-600",
                  delay: 0,
                },
                {
                  title: "Segurança",
                  description:
                    "Oferecemos recursos como segmentação de tráfego, VLANs e controle de acesso, protegendo informações sensíveis contra acessos não autorizados.",
                  icon: <Lock className="w-12 h-12" />,
                  color: "from-blue-600 to-cyan-600",
                  delay: 0.1,
                },
                {
                  title: "Escalabilidade",
                  description:
                    "Facilitamos a expansão da rede com switches que permitem a adição de novos dispositivos sem comprometer a performance e estabilidade.",
                  icon: <LayoutGrid className="w-12 h-12" />,
                  color: "from-indigo-600 to-purple-600",
                  delay: 0.2,
                },
                {
                  title: "Gerenciamento",
                  description:
                    "Disponibilizamos recursos de monitoramento e diagnóstico que permitem identificar e solucionar problemas na rede de forma rápida e eficiente.",
                  icon: <LineChart className="w-12 h-12" />,
                  color: "from-purple-600 to-pink-600",
                  delay: 0.3,
                },
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={featuresInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.8, delay: feature.delay }}
                  whileHover={{ y: -10, transition: { duration: 0.3 } }}
                  className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 relative overflow-hidden group"
                >
                  <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${feature.color}`}></div>
                  <div className="absolute top-0 left-0 w-0 h-full bg-gradient-to-r from-purple-50 to-transparent group-hover:w-full transition-all duration-700 ease-out"></div>

                  <div
                    className={`mb-6 text-transparent bg-gradient-to-r ${feature.color} bg-clip-text relative z-10 transition-transform duration-300 group-hover:scale-110`}
                  >
                    {feature.icon}
                  </div>

                  <h3 className="text-xl font-bold mb-4 text-[#1a0b2e] group-hover:text-[#9333ea] transition-colors relative z-10">
                    {feature.title}
                  </h3>

                  <p className="text-gray-600 relative z-10">{feature.description}</p>

                  <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-purple-300 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Products Section - Bloco 4 */}
        <section ref={productsRef} className="py-24 bg-[#f8f9fa] relative overflow-hidden">
          {/* Background elements */}
          <div className="absolute inset-0 bg-[url('/images/grid-pattern.svg')] opacity-5"></div>
          <motion.div
            className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_0%_50%,rgba(147,51,234,0.1)_0%,rgba(0,0,0,0)_70%)]"
            style={{
              y: useTransform(
                scrollY,
                [productsRef.current?.offsetTop || 0, (productsRef.current?.offsetTop || 0) + 300],
                [0, 100],
              ),
            }}
          ></motion.div>
          <motion.div
            className="absolute bottom-0 right-0 w-96 h-96 bg-[#4f46e5] rounded-full filter blur-[150px] opacity-10"
            animate={{
              x: [0, -50, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 18,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />

          <div className="container px-4 md:px-6 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={productsInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                Soluções
              </div>
              <h2 className="text-4xl font-bold mb-6 text-[#1a0b2e]">CONHEÇA NOSSOS PRODUTOS</h2>
              <div className="w-32 h-1 bg-gradient-to-r from-[#9333ea] to-[#4f46e5] mx-auto"></div>
              <p className="mt-6 text-gray-600 max-w-3xl mx-auto">
                Oferecemos uma ampla gama de switches de alta performance para atender às necessidades específicas da
                sua infraestrutura de rede.
              </p>
            </motion.div>

            {/* Product Showcase */}
            <div className="mb-20">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-bold text-[#1a0b2e]">Marcas Parceiras</h3>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    className="rounded-full hover:bg-[#9333ea]/10 hover:text-[#9333ea]"
                    onClick={() => setActiveProduct((prev) => (prev === 0 ? products.length - 1 : prev - 1))}
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="rounded-full hover:bg-[#9333ea]/10 hover:text-[#9333ea]"
                    onClick={() => setActiveProduct((prev) => (prev + 1) % products.length)}
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              <div className="relative">
                {products.map((product, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0 }}
                    animate={{
                      opacity: activeProduct === index ? 1 : 0,
                      x: activeProduct === index ? 0 : activeProduct > index ? -100 : 100,
                    }}
                    transition={{ duration: 0.5 }}
                    className={`${activeProduct === index ? "block" : "hidden"} bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-500 group`}
                  >
                    <div className={`bg-gradient-to-r ${product.color} p-6 relative overflow-hidden`}>
                      <div className="absolute inset-0 bg-[url('/images/circuit-pattern.svg')] opacity-20"></div>
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-2xl font-bold text-white mb-2">{product.name}</h3>
                          <p className="text-white/80 text-lg">{product.tagline}</p>
                        </div>
                        <div className="bg-white/10 p-4 rounded-xl backdrop-blur-sm">{product.icon}</div>
                      </div>
                    </div>

                    <div className="p-6 grid md:grid-cols-2 gap-6">
                      <div>
                        <div className="space-y-4 mb-6">
                          {product.description.map((paragraph, i) => (
                            <p key={i} className="text-gray-700">
                              {paragraph}
                            </p>
                          ))}
                        </div>

                        <h4 className="font-semibold text-lg mb-3 text-gray-900">Principais características:</h4>
                        <ul className="grid gap-2 mb-6">
                          {product.features.map((feature, i) => (
                            <li key={i} className="flex items-center gap-2 text-gray-700">
                              <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0" />
                              <span>{feature}</span>
                            </li>
                          ))}
                        </ul>

                        <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
                          <Button
                            className={`w-full bg-gradient-to-r ${product.color} text-white px-8 py-6 h-auto rounded-full group relative overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300`}
                          >
                            <span className="relative z-10">SOLICITAR ORÇAMENTO!</span>
                            <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1 relative z-10" />
                            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                          </Button>
                        </motion.div>
                      </div>

                      <div className="flex items-center justify-center bg-gray-50 rounded-xl p-4">
                        <motion.div
                          animate={{
                            y: [0, -10, 0],
                            rotate: [0, 2, 0, -2, 0],
                          }}
                          transition={{
                            duration: 5,
                            repeat: Number.POSITIVE_INFINITY,
                            repeatType: "reverse",
                          }}
                        >
                          <Image
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            width={400}
                            height={400}
                            className="object-contain max-h-80 transition-transform duration-500 group-hover:scale-105"
                          />
                        </motion.div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Product navigation dots */}
              <div className="flex justify-center mt-6 gap-2">
                {products.map((_, index) => (
                  <button
                    key={index}
                    className={`w-3 h-3 rounded-full transition-all ${
                      index === activeProduct ? "bg-[#9333ea] scale-125" : "bg-gray-300 hover:bg-gray-400"
                    }`}
                    onClick={() => setActiveProduct(index)}
                    aria-label={`View product ${index + 1}`}
                  />
                ))}
              </div>
            </div>

            {/* CTA Section */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              viewport={{ once: true }}
              className="mt-16"
            >
              <div className="bg-gradient-to-r from-[#1a0b2e] to-[#3a1e56] rounded-2xl p-8 md:p-12 relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('/images/circuit-pattern.svg')] opacity-10"></div>
                <div className="absolute top-0 right-0 w-96 h-96 bg-[#9333ea] rounded-full filter blur-[100px] opacity-20"></div>

                <div className="relative z-10 grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <h3 className="text-3xl font-bold text-white mb-4">Não encontrou o que procura?</h3>
                    <p className="text-white/80 mb-6">
                      Nossa equipe de especialistas está pronta para ajudar você a encontrar a solução ideal para sua
                      infraestrutura de rede. Entre em contato conosco para uma consultoria personalizada.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        <Button className="bg-white text-[#1a0b2e] hover:bg-white/90 px-8 py-6 h-auto rounded-md text-lg font-semibold">
                          Fale com um especialista
                        </Button>
                      </motion.div>
                      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        <Button
                          variant="outline"
                          className="border-white text-white hover:bg-white/10 px-8 py-6 h-auto rounded-md text-lg font-semibold"
                        >
                          Ver todos os produtos
                        </Button>
                      </motion.div>
                    </div>
                  </div>
                  <div className="flex justify-center">
                    <motion.div
                      className="bg-white/10 backdrop-blur-sm rounded-full p-8 w-64 h-64 flex items-center justify-center"
                      animate={{
                        rotate: [0, 5, 0, -5, 0],
                      }}
                      transition={{
                        duration: 10,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "reverse",
                      }}
                    >
                      <Image
                        src="/ufispace.png"
                        alt="Suporte técnico"
                        width={200}
                        height={200}
                        className="object-contain"
                      />
                    </motion.div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Why Choose Us Section - Bloco 5 */}
        <section ref={whyUsRef} className="py-20 bg-[#1a0b2e] text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('/images/grid-pattern.svg')] opacity-5"></div>
          <motion.div
            className="absolute top-0 right-0 w-96 h-96 bg-[#9333ea] rounded-full filter blur-[150px] opacity-10"
            animate={{
              x: [0, 50, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 15,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
          <motion.div
            className="absolute bottom-0 left-0 w-96 h-96 bg-[#4f46e5] rounded-full filter blur-[150px] opacity-20"
            animate={{
              x: [0, -50, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 18,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />

          <div className="container px-4 md:px-6 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={whyUsInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 px-3 py-1 bg-white/10 text-white rounded-full text-sm font-medium backdrop-blur-sm">
                Diferenciais
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Por que escolher a VTelco?</h2>
              <div className="w-20 h-1 bg-gradient-to-r from-[#9333ea] to-[#4f46e5] mx-auto"></div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  title: "Conhecimento técnico avançado",
                  description:
                    "Contamos com uma equipe altamente qualificada e com vasta experiência em redes de telecomunicações para garantir a implementação e o suporte técnico de soluções complexas.",
                  icon: <Lightbulb className="h-8 w-8" />,
                  delay: 0,
                },
                {
                  title: "Facilidade de pagamento",
                  description:
                    "Oferecemos opções de pagamento facilitadas e licenças mensais, que se adaptam ao seu orçamento e fluxo de caixa.",
                  icon: <CreditCard className="h-8 w-8" />,
                  delay: 0.1,
                },
                {
                  title: "Rede ampla de fornecedores",
                  description:
                    "Temos um portfólio completo de produtos e soluções para que você personalize sua infraestrutura, de acordo com suas necessidades específicas.",
                  icon: <Network className="h-8 w-8" />,
                  delay: 0.2,
                },
              ].map((reason, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={whyUsInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.8, delay: reason.delay }}
                  whileHover={{ y: -10, transition: { duration: 0.3 } }}
                  className="bg-gradient-to-br from-[#2a0e46] to-[#3a1e56] p-8 rounded-xl border border-[#3a1e56] hover:bg-[#3a1e56] transition-all duration-300 shadow-lg shadow-purple-900/20 hover:shadow-purple-900/40 relative overflow-hidden group"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-[#9333ea]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div className="w-16 h-16 rounded-full bg-[#9333ea]/20 flex items-center justify-center mb-6 group-hover:bg-[#9333ea]/30 transition-colors duration-300">
                    <span className="text-[#9333ea] group-hover:text-white transition-colors duration-300">
                      {reason.icon}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-4 group-hover:text-white transition-colors">{reason.title}</h3>
                  <p className="text-white/80 group-hover:text-white/90 transition-colors">{reason.description}</p>
                  <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#9333ea] to-[#4f46e5] transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* About Section - Bloco 6 */}
        <section ref={aboutRef} className="py-20 bg-white" id="sobre">
          <div className="container px-4 md:px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={aboutInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.8 }}
              >
                <div className="inline-block mb-4 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                  Sobre Nós
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6 text-[#1a0b2e]">Quem somos?</h2>
                <p className="text-gray-700 mb-6 text-lg">
                  Formada por profissionais com mais de duas décadas de experiência no setor, a VTelco trouxe uma nova
                  abordagem para o mercado, ao adotar os conceitos de redes abertas e desagregadas, rompendo com as
                  barreiras tradicionais e oferecendo aos clientes maior flexibilidade e controle sobre suas
                  infraestruturas de rede.
                </p>
                <p className="text-gray-700 mb-8 text-lg">
                  Nossa missão é ser reconhecida como líder nacional na criação de soluções inovadoras, impulsionando o
                  progresso da sociedade e o sucesso de nossos clientes.
                </p>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button className="bg-gradient-to-r from-[#9333ea] to-[#4f46e5] hover:from-[#8323d5] hover:to-[#4038c7] text-white px-8 py-6 h-auto rounded-full group relative overflow-hidden shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all duration-300">
                    <span className="relative z-10">QUERO SABER MAIS!</span>
                    <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1 relative z-10" />
                  </Button>
                </motion.div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={aboutInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative"
              >
                <div className="relative rounded-2xl overflow-hidden shadow-xl">
                  <div className="absolute inset-0 bg-gradient-to-br from-[#1a0b2e] via-[#2a0e46] to-[#3a1e56] opacity-80"></div>
                  <div className="aspect-video relative z-10 flex items-center justify-center p-8">
                    <motion.div
                      animate={{
                        scale: [1, 1.05, 1],
                      }}
                      transition={{
                        duration: 4,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "reverse",
                      }}
                    >
                      <Image
                        src="/logo-footer.png"
                        alt="VTelco"
                        width={300}
                        height={100}
                        className="w-3/4 h-auto"
                      />
                    </motion.div>
                  </div>
                </div>

                <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-[#9333ea]/20 rounded-full blur-xl"></div>
                <div className="absolute -top-6 -left-6 w-32 h-32 bg-[#4f46e5]/20 rounded-full blur-xl"></div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Contact Form Section - Bloco 6 */}
        <section ref={contactRef} className="py-20 bg-[#f8f9fa] relative overflow-hidden" id="formulario">
          <motion.div
            className="absolute top-0 right-0 w-96 h-96 bg-[#9333ea] rounded-full filter blur-[150px] opacity-10"
            animate={{
              x: [0, 50, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 15,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />

          <div className="container px-4 md:px-6 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={contactInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <div className="inline-block mb-4 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                Contato
              </div>
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
                className="text-3xl md:text-4xl font-bold mb-6 text-[#1a0b2e]"
              >
                VTelco: Simplificando sua rede
              </motion.h2>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                viewport={{ once: true }}
                className="text-gray-700 max-w-2xl mx-auto"
              >
                Preencha seus dados e encontre o switch ideal para sua infraestrutura de rede.
              </motion.p>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                viewport={{ once: true }}
                className="w-20 h-1 bg-gradient-to-r from-[#9333ea] to-[#4f46e5] mx-auto mt-6"
              ></motion.div>
            </motion.div>

            <div className="max-w-3xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
                className="bg-white rounded-xl shadow-2xl p-8 border border-gray-200 hover:shadow-purple-500/10 transition-shadow duration-300"
              >
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: 0.3 }}
                      viewport={{ once: true }}
                    >
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Nome
                      </label>
                      <Input
                        id="name"
                        placeholder="Seu nome completo"
                        className="w-full focus:ring-[#9333ea] focus:border-[#9333ea] transition-all duration-300"
                      />
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: 0.3 }}
                      viewport={{ once: true }}
                    >
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Email
                      </label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="seu@email.com"
                        className="w-full focus:ring-[#9333ea] focus:border-[#9333ea] transition-all duration-300"
                      />
                    </motion.div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: 0.4 }}
                      viewport={{ once: true }}
                    >
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        Telefone
                      </label>
                      <Input
                        id="phone"
                        placeholder="(00) 00000-0000"
                        className="w-full focus:ring-[#9333ea] focus:border-[#9333ea] transition-all duration-300"
                      />
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: 0.4 }}
                      viewport={{ once: true }}
                    >
                      <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-1">
                        Empresa
                      </label>
                      <Input
                        id="company"
                        placeholder="Nome da sua empresa"
                        className="w-full focus:ring-[#9333ea] focus:border-[#9333ea] transition-all duration-300"
                      />
                    </motion.div>
                  </div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.5 }}
                    viewport={{ once: true }}
                  >
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Mensagem
                    </label>
                    <Textarea
                      id="message"
                      placeholder="Descreva sua necessidade..."
                      rows={4}
                      className="w-full focus:ring-[#9333ea] focus:border-[#9333ea] transition-all duration-300"
                    />
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.6 }}
                    viewport={{ once: true }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Button className="w-full bg-gradient-to-r from-[#9333ea] to-[#4f46e5] hover:from-[#8323d5] hover:to-[#4038c7] text-white px-8 py-6 h-auto rounded-md group relative overflow-hidden shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all duration-300">
                      <span className="relative z-10">ENVIAR MENSAGEM</span>
                      <Send className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1 relative z-10" />
                    </Button>
                  </motion.div>
                </form>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Contact Info Section - Bloco 7 */}
        <section className="py-20 bg-white">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-6 text-[#1a0b2e]">Contato</h2>
              <div className="w-20 h-1 bg-gradient-to-r from-[#9333ea] to-[#4f46e5] mx-auto"></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
                className="bg-[#f8f9fa] p-8 rounded-xl border border-gray-200 hover:shadow-lg transition-shadow duration-300"
              >
                <h3 className="text-xl font-bold mb-6 text-[#1a0b2e] flex items-center">
                  <MapPin className="mr-2 h-5 w-5 text-purple-600" />
                  Matriz Brasil
                </h3>
                <ul className="space-y-4 text-gray-700">
                  <li className="flex items-start gap-3">
                    <Phone className="h-5 w-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <span>+55 (41) 99988-9681</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Mail className="h-5 w-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <span>contato@vtelco.com.br</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <span>Rua Imaculada Conceição, 1430 – Prado Velho, Curitiba – PR, 80215-182</span>
                  </li>
                </ul>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                viewport={{ once: true }}
                className="bg-[#f8f9fa] p-8 rounded-xl border border-gray-200 hover:shadow-lg transition-shadow duration-300"
              >
                <h3 className="text-xl font-bold mb-6 text-[#1a0b2e] flex items-center">
                  <MapPin className="mr-2 h-5 w-5 text-blue-600" />
                  Filial EUA
                </h3>
                <ul className="space-y-4 text-gray-700">
                  <li className="flex items-start gap-3">
                    <Phone className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <span>+55 (41) 99988-9681</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <Mail className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <span>contato@vtelco.com.br</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <span>1191 E Newport Center Dr STE 103 - Deerfield Beach, FL 33442</span>
                  </li>
                </ul>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-[#1a0b2e] text-white py-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/grid-pattern.svg')] opacity-5"></div>
        <motion.div
          className="absolute top-0 right-0 w-96 h-96 bg-[#9333ea] rounded-full filter blur-[150px] opacity-10"
          animate={{
            x: [0, 50, 0],
            y: [0, 30, 0],
          }}
          transition={{
            duration: 15,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />

        <div className="container px-4 md:px-6 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <Link href="/" className="block mb-4 group">
                <Image
                  src="/logo.png"
                  alt="VTelco"
                  width={150}
                  height={50}
                  className="h-10 w-auto transition-transform duration-300 group-hover:scale-105"
                />
              </Link>
              <div className="flex space-x-2 mb-4">
                <span className="text-yellow-400">★</span>
                <span className="text-yellow-400">★</span>
                <span className="text-yellow-400">★</span>
                <span className="text-yellow-400">★</span>
                <span className="text-yellow-400">★</span>
              </div>
              <p className="text-gray-400 text-sm">Simplificando sua rede</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              viewport={{ once: true }}
            >
              <h4 className="font-medium mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-400">
                Links rápidos
              </h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors inline-flex items-center group">
                    <span className="relative">
                      Home
                      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
                    </span>
                    <ArrowRight className="ml-2 h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors inline-flex items-center group">
                    <span className="relative">
                      Soluções
                      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
                    </span>
                    <ArrowRight className="ml-2 h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors inline-flex items-center group">
                    <span className="relative">
                      Sobre Nós
                      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
                    </span>
                    <ArrowRight className="ml-2 h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors inline-flex items-center group">
                    <span className="relative">
                      Contato
                      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
                    </span>
                    <ArrowRight className="ml-2 h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </Link>
                </li>
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h4 className="font-medium mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-400">
                Soluções
              </h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors inline-flex items-center group">
                    <span className="relative">
                      Switches
                      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
                    </span>
                    <ArrowRight className="ml-2 h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors inline-flex items-center group">
                    <span className="relative">
                      Roteadores
                      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
                    </span>
                    <ArrowRight className="ml-2 h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors inline-flex items-center group">
                    <span className="relative">
                      Virtualização
                      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
                    </span>
                    <ArrowRight className="ml-2 h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors inline-flex items-center group">
                    <span className="relative">
                      Segurança
                      <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#9333ea] group-hover:w-full transition-all duration-300"></span>
                    </span>
                    <ArrowRight className="ml-2 h-3 w-3 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                  </Link>
                </li>
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              viewport={{ once: true }}
            >
              <h4 className="font-medium mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-blue-400">
                Newsletter
              </h4>
              <p className="text-gray-400 text-sm mb-4">
                Receba novidades e ofertas exclusivas diretamente no seu email.
              </p>
              <div className="flex">
                <Input
                  placeholder="Seu email"
                  className="bg-white/5 border-white/10 text-white rounded-r-none focus:ring-[#9333ea] focus:border-[#9333ea]"
                />
                <Button className="bg-gradient-to-r from-[#9333ea] to-[#4f46e5] hover:from-[#8323d5] hover:to-[#4038c7] rounded-l-none">
                  <Send className="h-5 w-5" />
                </Button>
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
            className="border-t border-gray-800 pt-8"
          >
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-center md:text-left text-gray-400 text-sm">
                © {new Date().getFullYear()} VTelco. Todos os direitos reservados.
              </p>
              <div className="flex space-x-4 mt-4 md:mt-0">
                <Link href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Política de Privacidade
                </Link>
                <Link href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                  Termos de Uso
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </footer>
    </div>
  )
}

