"use client"

import Image from "next/image"
import Link from "next/link"
import {
  ArrowRight,
  CheckCircle,
  Facebook,
  Instagram,
  Linkedin,
  MessageCircle,
  Network,
  Shield,
  Youtube,
  Zap,
} from "lucide-react"
import ContactForm from "@/components/contact-form"
import { useEffect, useRef } from "react"
import { motion } from "framer-motion"

export default function Home() {
  const observerRef = useRef<IntersectionObserver | null>(null)

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in")
          }
        })
      },
      { threshold: 0.1 },
    )

    const elements = document.querySelectorAll(".animate-on-scroll")
    elements.forEach((el) => observerRef.current?.observe(el))

    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect()
      }
    }
  }, [])

  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full bg-white shadow-sm">
        <div className="container mx-auto flex items-center justify-between py-3 px-4">
          <div className="flex items-center">
            <Link href="/" className="mr-8">
              <Image src="/vtelco-logo-black.png" alt="VTELCO" width={150} height={40} className="h-10 w-auto" />
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-sm font-medium text-gray-800 hover:text-purple-700 transition-colors">
                Home
              </Link>
              <Link
                href="/solucoes"
                className="text-sm font-medium text-gray-800 hover:text-purple-700 transition-colors"
              >
                Soluções
              </Link>
              <Link
                href="/sobre-nos"
                className="text-sm font-medium text-gray-800 hover:text-purple-700 transition-colors"
              >
                Sobre Nós
              </Link>
              <Link
                href="/contato"
                className="text-sm font-medium text-gray-800 hover:text-purple-700 transition-colors"
              >
                Contato
              </Link>
            </nav>
          </div>
          <div>
            <Link
              href="/contato"
              className="hidden md:inline-flex items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600 px-6 py-2.5 text-sm font-medium text-white hover:from-purple-600 hover:to-purple-700 transition-colors"
            >
              Entre em contato
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section - Bloco 1 */}
        <section className="relative overflow-hidden bg-black min-h-[600px] flex items-center">
          <div className="absolute inset-0 z-0">
            <Image src="/hero-background.png" alt="Background" fill className="object-cover" priority />
          </div>
          <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="space-y-6"
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                  className="inline-flex items-center rounded-full bg-white/10 px-3 py-1 text-sm text-white backdrop-blur-sm"
                >
                  <span className="font-medium">VTelco Networks</span>
                </motion.div>
                <motion.h1
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4, duration: 0.8 }}
                  className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight"
                >
                  CONECTIVIDADE SEM LIMITES
                </motion.h1>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6, duration: 0.8 }}
                  className="text-lg text-white/80"
                >
                  Switches de alto desempenho para elevar o nível da sua rede
                </motion.p>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8, duration: 0.8 }}
                  className="text-white/80"
                >
                  A VTelco dispõe de uma ampla variedade de switches de alta performance, garantindo escalabilidade,
                  segurança, gerenciamento simplificado e baixa latência para um fluxo de dados ágil e confiável.
                </motion.p>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1, duration: 0.5 }}
                  className="flex flex-col sm:flex-row gap-4"
                >
                  <Link
                    href="#contact"
                    className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600 px-6 py-3 text-base font-medium text-white hover:from-purple-600 hover:to-purple-700 transition-colors"
                  >
                    QUERO SABER MAIS!
                  </Link>
                </motion.div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5, duration: 1 }}
                className="flex justify-center"
              >
                <Image
                  src="/vtelco-logo-white.png"
                  alt="VTELCO"
                  width={400}
                  height={120}
                  className="object-contain drop-shadow-2xl"
                />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Intro Section - Bloco 2 */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto animate-on-scroll">
              <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center text-purple-900">
                Conectividade, escalabilidade e segurança para sua empresa
              </h2>
              <p className="text-gray-700 mb-6">
                Switches são dispositivos de rede que atuam como pontos de conexão entre vários dispositivos em uma rede
                local. Eles são responsáveis por encaminhar o tráfego de dados entre os dispositivos conectados,
                garantindo que as informações cheguem ao seu destino de forma rápida e eficiente.
              </p>
              <p className="text-gray-700 mb-8">
                Investir em switches de qualidade significa reduzir falhas na comunicação, aumentar a produtividade e
                fortalecer infraestruturas de TI, tornando sua empresa mais preparada para crescer e se adaptar às
                demandas do mercado digital.
              </p>
              <div className="flex justify-center">
                <Link
                  href="#contact"
                  className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600 px-6 py-3 text-base font-medium text-white hover:from-purple-600 hover:to-purple-700 transition-colors"
                >
                  QUERO SABER MAIS!
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section - Bloco 3 */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <motion.div
                whileHover={{ y: -10, boxShadow: "0 10px 25px -5px rgba(124, 58, 237, 0.2)" }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow animate-on-scroll"
              >
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                    <Zap className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-bold text-purple-900">Desempenho</h3>
                </div>
                <p className="text-gray-600">
                  Garantimos uma comunicação rápida e eficiente entre dispositivos, reduzindo congestionamentos e
                  otimizando a transmissão de dados.
                </p>
              </motion.div>

              <motion.div
                whileHover={{ y: -10, boxShadow: "0 10px 25px -5px rgba(124, 58, 237, 0.2)" }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow animate-on-scroll"
              >
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                    <Shield className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-bold text-purple-900">Segurança</h3>
                </div>
                <p className="text-gray-600">
                  Oferecemos recursos como segmentação de tráfego, VLANs e controle de acesso, protegendo informações
                  sensíveis contra acessos não autorizados.
                </p>
              </motion.div>

              <motion.div
                whileHover={{ y: -10, boxShadow: "0 10px 25px -5px rgba(124, 58, 237, 0.2)" }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow animate-on-scroll"
              >
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                    <ArrowRight className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-bold text-purple-900">Escalabilidade</h3>
                </div>
                <p className="text-gray-600">
                  Facilitamos a expansão da rede com switches que permitem a adição de novos dispositivos sem
                  comprometer a performance e estabilidade.
                </p>
              </motion.div>

              <motion.div
                whileHover={{ y: -10, boxShadow: "0 10px 25px -5px rgba(124, 58, 237, 0.2)" }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow animate-on-scroll"
              >
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                    <Network className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-bold text-purple-900">Gerenciamento</h3>
                </div>
                <p className="text-gray-600">
                  Disponibilizamos recursos de monitoramento e diagnóstico que permitem identificar e solucionar
                  problemas na rede de forma rápida e eficiente.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Products Section - Bloco 4 */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-bold mb-12 text-center text-purple-900 glow-text">
              CONHEÇA NOSSOS PRODUTOS
            </h2>

            <div className="grid grid-cols-1 gap-12">
              {/* UFI Space */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8 }}
                className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1 bg-gradient-to-br from-purple-800 to-blue-900 p-6 flex flex-col items-center justify-center">
                    <h3 className="text-2xl font-bold text-white text-center mb-4 glow-text-white">UFI Space</h3>
                    <Image
                      src="/ufispace-switch.png"
                      alt="UFI Space Switch"
                      width={200}
                      height={100}
                      className="object-contain drop-shadow-xl"
                    />
                  </div>
                  <div className="md:col-span-2 p-6">
                    <p className="text-gray-700 mb-6">
                      A UfiSpace, fundada em 2015 e com sede em Taiwan, é especializada em switches de alta performance
                      para provedores de serviços e data centers. Para provedores de serviços, a empresa oferece
                      equipamentos que variam de 4 portas de 1 Gbps a 36 portas de 400 Gbps, ideais para roteadores de
                      Ponto de Entrada (PE) e Borda, proporcionando flexibilidade e alta capacidade para gerenciar redes
                      complexas e grandes volumes de tráfego, com suporte a protocolos como BGP e MPLS, além de serviços
                      como L2VPN e L3VPN.
                    </p>
                    <p className="text-gray-700 mb-6">
                      Já para data centers, a UfiSpace disponibiliza switches de alta capacidade, com opções que variam
                      de 24 portas de 10 Gbps a 64 portas de 800 Gbps, garantindo a transferência eficiente de grandes
                      volumes de dados.
                    </p>
                    <Link
                      href="#contact"
                      className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600 px-6 py-3 text-base font-medium text-white hover:from-purple-600 hover:to-purple-700 transition-colors"
                    >
                      SOLICITE UM ORÇAMENTO!
                    </Link>
                  </div>
                </div>
              </motion.div>

              {/* Edgecore Networks */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8 }}
                className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1 bg-gradient-to-br from-purple-800 to-blue-900 p-6 flex flex-col items-center justify-center">
                    <h3 className="text-2xl font-bold text-white text-center mb-4 glow-text-white">
                      Edgecore Networks
                    </h3>
                    <Image
                      src="/edgecore-switch.png"
                      alt="Edgecore Networks Switch"
                      width={200}
                      height={100}
                      className="object-contain drop-shadow-xl"
                    />
                  </div>
                  <div className="md:col-span-2 p-6">
                    <p className="text-gray-700 mb-6">
                      A Edgecore Networks, fundada em 2004, é líder no fornecimento de soluções de rede desagregadas e
                      de código aberto. A Edgecore se destaca por permitir que operadoras de telecomunicações,
                      provedores de serviços e data centers construam redes personalizadas, escaláveis e eficientes, por
                      meio de uma arquitetura modular e redundante.
                    </p>
                    <p className="text-gray-700 mb-6">
                      Para data centers, a Edgecore oferece switches de alta capacidade com portas de 1 Gbps até 400
                      Gbps, enquanto para empresas, disponibiliza uma linha completa de switches L2 e L3 e Wi-Fi. Além
                      disso, a Edgecore é referência em switches PoE, com portas que variam de 8 a 48 e entregam
                      desempenho superior para setores que exigem conectividade e alta performance.
                    </p>
                    <Link
                      href="#contact"
                      className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600 px-6 py-3 text-base font-medium text-white hover:from-purple-600 hover:to-purple-700 transition-colors"
                    >
                      SOLICITE UM ORÇAMENTO!
                    </Link>
                  </div>
                </div>
              </motion.div>

              {/* Asterfusion */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8 }}
                className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1 bg-gradient-to-br from-purple-800 to-blue-900 p-6 flex flex-col items-center justify-center">
                    <h3 className="text-2xl font-bold text-white text-center mb-4 glow-text-white">Asterfusion</h3>
                    <Image
                      src="/asterfusion-switch.png"
                      alt="Asterfusion Switch"
                      width={200}
                      height={100}
                      className="object-contain drop-shadow-xl"
                    />
                  </div>
                  <div className="md:col-span-2 p-6">
                    <p className="text-gray-700 mb-6">
                      A Asterfusion é uma empresa especializada em soluções de rede desagregada e de código aberto,
                      projetadas para atender às necessidades de data centers, provedores de nuvem e redes de
                      telecomunicações. Focada em infraestrutura escalável e flexível, a Asterfusion oferece switches e
                      roteadores de alta performance que suportam redes definidas por software (SDN) e virtualização de
                      funções de rede (NFV).
                    </p>
                    <p className="text-gray-700 mb-6">
                      Para data centers, a empresa disponibiliza switches com ultra baixa latência (400 ns) e
                      capacidades de até 36 portas de 400 Gbps, ideais para ambientes que exigem altíssima performance e
                      transferência rápida de dados. Seus switches para empresas variam de 1 Gbps a 400 Gbps, oferecendo
                      uma solução flexível para empresas que buscam aumentar a capacidade e a eficiência de suas redes.
                    </p>
                    <Link
                      href="#contact"
                      className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600 px-6 py-3 text-base font-medium text-white hover:from-purple-600 hover:to-purple-700 transition-colors"
                    >
                      SOLICITE UM ORÇAMENTO!
                    </Link>
                  </div>
                </div>
              </motion.div>

              {/* ACORID */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8 }}
                className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1 bg-gradient-to-br from-purple-800 to-blue-900 p-6 flex flex-col items-center justify-center">
                    <h3 className="text-2xl font-bold text-white text-center mb-4 glow-text-white">ACORID</h3>
                    <Image
                      src="/acorid-switch.png"
                      alt="ACORID Switch"
                      width={200}
                      height={100}
                      className="object-contain drop-shadow-xl"
                    />
                  </div>
                  <div className="md:col-span-2 p-6">
                    <p className="text-gray-700 mb-6">
                      A ACORID é uma empresa chinesa especializada em soluções de rede para ambientes empresariais,
                      industriais e residenciais. Seu portfólio inclui switches PoE, Ethernet e industriais, oferecendo
                      um equilíbrio entre custo-benefício, eficiência e confiabilidade.
                    </p>
                    <p className="text-gray-700 mb-6">
                      Os switches PoE permitem a transmissão simultânea de dados e energia por meio de cabos Ethernet,
                      sendo ideais para alimentar dispositivos como câmeras IP, pontos de acesso Wi-Fi e telefones VoIP,
                      sem necessidade de fontes de energia externas. Já os switches Ethernet garantem conectividade
                      estável para pequenas e médias empresas, oferecendo alta velocidade e eficiência na transmissão de
                      dados. Além da performance, os equipamentos da ACORID contam com proteção contra sobrecarga de
                      energia e reinicializações inesperadas, garantindo maior segurança e durabilidade para redes em
                      diversos setores.
                    </p>
                    <Link
                      href="#contact"
                      className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600 px-6 py-3 text-base font-medium text-white hover:from-purple-600 hover:to-purple-700 transition-colors"
                    >
                      SOLICITE UM ORÇAMENTO!
                    </Link>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Why Choose Us - Bloco 5 */}
        <section className="py-16 bg-gradient-to-br from-purple-900 via-purple-800 to-blue-900 text-white bg-gradient-animate">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_70%,rgba(120,40,200,0.3)_0%,transparent_60%)]"></div>
          <div className="container mx-auto px-4 relative z-10">
            <h2 className="text-2xl md:text-3xl font-bold mb-12 text-center glow-text-white">
              Por que escolher a VTelco?
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <motion.div
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-white/30 transition-colors shadow-glow"
              >
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-full bg-purple-600/30 flex items-center justify-center mr-3">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold">Conhecimento técnico avançado</h3>
                </div>
                <p className="text-white/80">
                  Contamos com uma equipe altamente qualificada e com vasta experiência em redes de telecomunicações
                  para garantir a implementação e o suporte técnico de soluções complexas.
                </p>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-white/30 transition-colors shadow-glow"
              >
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-full bg-purple-600/30 flex items-center justify-center mr-3">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold">Facilidade de pagamento</h3>
                </div>
                <p className="text-white/80">
                  Oferecemos opções de pagamento facilitadas e licenças mensais, que se adaptam ao seu orçamento e fluxo
                  de caixa.
                </p>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:border-white/30 transition-colors shadow-glow"
              >
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-full bg-purple-600/30 flex items-center justify-center mr-3">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold">Rede ampla de fornecedores</h3>
                </div>
                <p className="text-white/80">
                  Temos um portfólio completo de produtos e soluções para que você personalize sua infraestrutura, de
                  acordo com suas necessidades específicas.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* About Us - Bloco 6 */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <h2 className="text-2xl md:text-3xl font-bold mb-6 text-purple-900">Quem somos?</h2>
                <p className="text-gray-700 mb-6">
                  Formada por profissionais com mais de duas décadas de experiência no setor, a VTelco trouxe uma nova
                  abordagem para o mercado, ao adotar os conceitos de redes abertas e desagregadas, rompendo com as
                  barreiras tradicionais e oferecendo aos clientes maior flexibilidade e controle sobre suas
                  infraestruturas de rede.
                </p>
                <p className="text-gray-700 mb-8">
                  Nossa missão é ser reconhecida como líder nacional na criação de soluções inovadoras, impulsionando o
                  progresso da sociedade e o sucesso de nossos clientes.
                </p>
                <Link
                  href="/sobre-nos"
                  className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-purple-500 to-purple-600 px-6 py-3 text-base font-medium text-white hover:from-purple-600 hover:to-purple-700 transition-colors"
                >
                  QUERO SABER MAIS!
                </Link>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="flex justify-center"
              >
                <div className="relative w-full max-w-md">
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl transform rotate-3"></div>
                  <div className="relative z-10 rounded-2xl shadow-xl bg-white p-8 flex items-center justify-center">
                    <Image
                      src="/vtelco-team.png"
                      alt="VTelco Team"
                      width={300}
                      height={200}
                      className="object-cover rounded-lg shadow-md"
                    />
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Contact Form - Bloco 6 */}
        <section id="contact" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center text-purple-900 glow-text">
                  VTelco: Simplificando sua rede
                </h2>
                <p className="text-gray-700 mb-8 text-center">
                  Preencha seus dados e encontre o switch ideal para sua infraestrutura de rede.
                </p>

                <ContactForm />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Contact Info - Bloco 7 */}
        <section className="py-16 bg-gradient-to-br from-purple-900 via-purple-800 to-blue-900 text-white bg-gradient-animate">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(120,40,200,0.3)_0%,transparent_60%)]"></div>
          <div className="container mx-auto px-4 relative z-10">
            <h2 className="text-2xl md:text-3xl font-bold mb-12 text-center glow-text-white">Contato</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <motion.div
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/10 hover:border-white/30 transition-colors shadow-glow"
              >
                <h3 className="text-xl font-bold mb-6 glow-text-white">Matriz Brasil</h3>
                <p className="mb-2">+55 (41) 99988-9681</p>
                <p className="mb-2">contato@vtelco.com.br</p>
                <p className="mb-2">Rua Imaculada Conceição, 1430 – Prado Velho, Curitiba – PR, 80215-182</p>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300 }}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/10 hover:border-white/30 transition-colors shadow-glow"
              >
                <h3 className="text-xl font-bold mb-6 glow-text-white">Filial EUA</h3>
                <p className="mb-2">+55 (41) 99988-9681</p>
                <p className="mb-2">contato@vtelco.com.br</p>
                <p className="mb-2">1191 E Newport Center Dr STE 103</p>
                <p className="mb-2">Deerfield Beach, FL 33442</p>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-black text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="flex flex-col items-center md:items-start">
              <Image src="/vtelco-logo-white.png" alt="VTELCO" width={180} height={50} className="mb-4" />
              <div className="flex space-x-4 mt-4">
                <Link
                  href="#"
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <Facebook className="w-4 h-4 text-white" />
                </Link>
                <Link
                  href="#"
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <Instagram className="w-4 h-4 text-white" />
                </Link>
                <Link
                  href="#"
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <Youtube className="w-4 h-4 text-white" />
                </Link>
                <Link
                  href="#"
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <Linkedin className="w-4 h-4 text-white" />
                </Link>
              </div>
            </div>

            <div className="text-center md:text-left">
              <h3 className="text-lg font-semibold mb-4 text-white/90">Matriz Brasil</h3>
              <p className="text-sm text-white/70 mb-1">+55 (41) 99988-9681</p>
              <p className="text-sm text-white/70 mb-1">contato@vtelco.com.br</p>
              <p className="text-sm text-white/70 mb-1">Rua Imaculada Conceição, 1430 – Prado Velho,</p>
              <p className="text-sm text-white/70 mb-1">Curitiba – PR, 80215-182</p>
              <p className="text-sm text-white/70 mt-2">CNPJ 52666557/0001-60</p>
            </div>

            <div className="text-center md:text-left">
              <h3 className="text-lg font-semibold mb-4 text-white/90">Filial EUA</h3>
              <p className="text-sm text-white/70 mb-1">+55 (41) 99988-9681</p>
              <p className="text-sm text-white/70 mb-1">contato@vtelco.com.br</p>
              <p className="text-sm text-white/70 mb-1">1191 E Newport Center Dr STE 103</p>
              <p className="text-sm text-white/70 mb-1">Deerfield Beach, FL 33442</p>
            </div>
          </div>

          <div className="border-t border-white/10 pt-6 text-center">
            <p className="text-sm text-white/60">© {new Date().getFullYear()} VTELCO. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>

      {/* WhatsApp Button */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1.5, type: "spring", stiffness: 260, damping: 20 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <Link
          href="https://wa.me/5541999889681"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center w-14 h-14 bg-green-500 rounded-full shadow-lg hover:bg-green-600 transition-colors hover:shadow-glow-green"
        >
          <MessageCircle className="w-7 h-7 text-white" />
        </Link>
      </motion.div>
    </div>
  )
}

